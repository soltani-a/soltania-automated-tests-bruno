# Diagnostic _time — version 13

Ce diagnostic conserve les requêtes v13 et ne remplace pas son design. Aucun réglage serveur n'est requis.

## Pourquoi vérifier la table

_time n'est ni une métrique ni un tag à ajouter. Datadog l'ajoute aux données d'une réponse Timeseries. Dans les fichiers v13 livrés : table1 = première requête Scalar, table2 = deuxième requête Timeseries CPU/RAM, table3 = troisième requête Scalar disques. L'absence de _time sur table1 et table3 est normale. Son absence sur une réponse Timeseries non vide nécessite de contrôler le type réellement enregistré et le mapping des données.

Le code v13 ne trace que les lignes où _time est numérique. Un _time absent, ou présent sous un autre type, peut donc expliquer une courbe vide. Seul le premier cas signifie réellement absence de colonne ; les compteurs de ce diagnostic distinguent ces situations.

## Test le plus court, sans changer les requêtes

1. Dupliquez le widget v13 concerné pour conserver l'original.
2. Dans la copie, gardez les trois requêtes dans leur ordre.
3. Dans Define Visual, mode Vega, remplacez seulement la définition visuelle par Probe-original-three-requests-VEGA.json.
4. Cliquez Run. Le panneau affiche, pour chaque table, le nombre de lignes reçues, le nombre de lignes portant _time, le nombre de _time numériques et quelques champs de la première ligne.
5. Communiquez les trois lignes table1/table2/table3 affichées. Les champs absents sont affichés comme undefined ; aucune date n'est fabriquée.

## Test comparatif complet

Importez le JSON portant le nom de l'application concernée comme nouveau dashboard. Exemple : 02-solutyo.json. Choisissez la même Saved View que dans le dashboard v13. Tous les widgets de diagnostic utilisent une heure et les requêtes d'origine.

A — Graphique natif : contrôle que la requête temporelle v13 renvoie des données.
B — Trois requêtes v13 : montre ce que reçoit chaque table avant tout filtre et toute jointure du dessin.
C — Requête Timeseries seule : identique à la deuxième requête v13, désormais dans table1 puisqu'elle est seule.
D — Courbe Wildcard minimale : utilise cette même requête seule, sans jointure avec les capacités RAM/disques ou le catalogue des hosts. CPU turquoise, RAM bleu.

## Interprétation

- B table1 sans _time mais B table2 avec _time numérique : le mapping temporel attendu est présent. Vérifier ensuite les aliases cpu_pct/ram_pct et les champs host/application, puis les jointures et filtres du composant v13.
- B table2 a des lignes, _time présent >0 et numérique =0 : le filtre isNumber du composant v13 élimine ces dates. Il faut adapter le traitement au type réellement reçu.
- B table2 sans _time, mais C avec _time et D visible : problème circonscrit à la configuration à plusieurs requêtes ou à son mapping ; les données et le rendu Wildcard simple fonctionnent. Comparer ensuite le JSON exporté depuis Datadog au JSON v13 fourni.
- B table2 vide, C rempli : vérifier la conservation et l'exécution de la deuxième requête à l'import et après sauvegarde.
- A visible mais C a des lignes sans _time : problème dans la réponse/mise en forme Wildcard de cette requête ou dans son type réellement enregistré ; l'export actuel du widget et les colonnes Data Preview sont nécessaires pour le déterminer.
- A et C vides : recontrôler environnement, période et scope. Le diagnostic ne change aucun tag.

Dans l'export du Wildcard v13, la deuxième entrée de requests doit contenir response_format: timeseries. Les première et troisième sont scalar. Une agrégation temporelle scalaire, par exemple last, produit une valeur résumée et ne constitue pas une série horodatée. Ne changez pas toutes les requêtes en Timeseries : cela modifierait le contrat des cartes.

Ne remplacez pas _time par now() : cela placerait des valeurs agrégées à l'heure courante et inventerait un historique.

## Limites

Schémas et visualisations testés localement. Pas de données de votre compte accessibles dans ce diagnostic préparé. Il sert à établir la cause ; ce n'est pas une affirmation qu'un correctif a été validé en production. Les fichiers de la v13 sont conservés intacts. Les demandes de contraste et d'emplacements C:/D: restent à intégrer au composant final une fois le mapping temporel confirmé.

Source : https://docs.datadoghq.com/dashboards/guide/using_vega_lite_in_wildcard_widgets/
