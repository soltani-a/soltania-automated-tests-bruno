# Build and maintain the VCA DSI application portfolio in Datadog

Version 14 · Updated 3 October 2026 · Audience: application owners, operations teams, solution architects and first-time Datadog dashboard builders.

## What you will build

One portfolio with three tabs: Overview, Hosts & Volumes, and Data Validation. Eight application cards display integrated CPU/RAM trends. All three tables display the friendly application name first. One dashboard follows each user's Datadog appearance and the top-right time selector.

No script, API key, server change or additional metric tag is required. You configure existing metrics and paste supplied Vega visual definitions. This procedure reproduces the dashboard widget by widget; it does not require writing the visual grammar from scratch.

Choose the quick import route to deploy the package. Choose the manual route to learn and recreate it. Do not perform both routes in the same dashboard.

## Prerequisites and files

You need access to the Datadog organization, permission to create/edit dashboards, the Wildcard widget, and the existing system metrics. The team handle vca-dsi should already exist for association. Orion also uses vca-orion-ops. Importing this package does not create teams or restrict access.

Extract the complete v14 ZIP. Keep its files together. The 01-Dashboards folder contains complete dashboards. The 02-Widgets/00-Portfolio folder contains Overview, Hosts, Volumes and Data-Validation components. Each has Request.json, Define-Visual-VEGA.json and Widget.json variants. Do not mix files from different releases.

A metric is a measured value. A tag filters or groups values. A formula calculates a displayed number. A request returns a dataset. Vega describes its presentation. Timeseries returns values over time, including _time; Scalar summarizes a selected period. A Saved View recalls filter selections.

> SCREENSHOT PLACEHOLDER — SS-01: Access and package
> Capture the Dashboards landing page and extracted v14 package. Replace this block with the screenshot and caption.

## Prepare the Confluence page

Create a page with this article's title. Open the supplied HTML article in a browser, copy its rendered article content into the page editor, then check headings, tables and code blocks. If formatting changes, use the Markdown file as the source and recreate affected blocks with Confluence's Heading, Table and Code block controls. The HTML is a reading/copying aid, not a claim that Confluence provides a native HTML import feature.

Attach the ZIP, 00-Portfolio.json, INVENTORY.json, APPLICATION-CATALOG.json and the four sets of component JSON files. Replace file references in this article with links to those attachments. Add a Table of Contents macro if useful. Attach your real screenshots as you complete the placeholders. Review the acceptance checklist before publishing.

## Supported inventory

The portfolio covers eight logical applications and 18 registered hosts. Friendly names are local JSON labels, not metric tags.

| Application | Application ID | Environment | Hosts |
|---|---|---|---|
| Sage 100 | app07656 | test | sapp01055 |
| Solutyo | app07739 | quality | sapp01051 |
| Solutyo | app07739 | production | sapp01077 |
| Neofugu | app08213 | quality | sapp01078 |
| Neofugu | app08213 | production | sapp01098 |
| VCA Orion | app05236 | quality | sapp00185, sapp00184, sapp01044, sapp01045 |
| VCA Orion | app05236 | pre-production | sapp00178, sapp00177 |
| VCA Orion | app05236 | production | sapp00175, sapp00176 |
| Magics LM | app05236 | prd | sapp01129 |
| Solidworks LM | app05236 | prd | slic00025 |
| Hypermill LM | app05236 | prd | slic00027 |
| Proconcept | app06976 | production | sapp00951, sora00003 |


Orion, Magics LM, Solidworks LM and Hypermill LM share app05236. Mapping only by application ID would be incorrect; the host and expected application ID distinguish them. Treasure Cloud / Stone Cloud is excluded from this release at the user's request.

## Route A — Quick import

1. Export the existing dashboard to preserve local changes and cockpit links. Create a new dashboard for the first validation.
2. Open the dashboard configuration/menu and choose Import dashboard JSON / Import from JSON. UI wording may vary.
3. Import 01-Dashboards/00-Portfolio.json. Widgets, tabs, variables, Saved Views and team metadata are included.
4. Confirm the VCA DSI title prefix and vca-dsi team. Select All environments initially, then Production.
5. Continue with the acceptance tests below. No separate widget installation is required.

Use Without-tabs/00-Portfolio.json only if your interface rejects tabs. It contains the same content sequentially; it is not a workaround for missing metrics.

> SCREENSHOT PLACEHOLDER — SS-02: Imported portfolio
> Capture the title, three tabs, environment filter and global time selector.

## Route B — Recreate the portfolio manually

### Step 1 — Create the dashboard and associate the team

Create an ordered dashboard titled VCA DSI | Application Portfolio | v14. Suggested description: Infrastructure resource overview for the VCA DSI application inventory. Resource pressure is not application availability.

Hover over the dashboard title to open its details and associate the existing vca-dsi team. The export should contain this top-level property:

```json
"tags": ["team:vca-dsi"]
```

This is dashboard ownership metadata. Do not put team:vca-dsi in metric queries: the collected data does not require this tag. Orion's separate dashboard has team:vca-dsi and team:vca-orion-ops; the portfolio has vca-dsi only.

> SCREENSHOT PLACEHOLDER — SS-03: Title and ownership
> Capture the details panel with the correct title and selected vca-dsi team.

### Step 2 — Create the environment variable

Add a template variable named environment with tag prefix environment. Its available values are test, quality, pre-production, production and prd. The supplied metric queries reference $environment. Use the same spelling and case.

The variable filters existing tags; it does not create them. The maison:vca, application ID and host filters are already in each supplied request.

> SCREENSHOT PLACEHOLDER — SS-04: Environment variable
> Capture its name, prefix and five available values.

### Step 3 — Create Saved Views

| Saved View | Selected environment values |
|---|---|
| Production | production and prd together |
| Quality | quality |
| Test | test |
| Pre-production | pre-production |
| All environments | All five values |

Set Production as the default if the interface offers that control; otherwise save with production and prd selected and use the delivered JSON defaults as the reference. Production is a saved two-value selection, not an automatic alias conversion. Selecting production alone does not include prd. Test and Quality remain distinct; Sage 100 is Test-only.

> SCREENSHOT PLACEHOLDER — SS-05: Production aliases
> Capture the Production Saved View and both production/prd in the filter.

### Step 4 — Create tabs

Create Overview, Hosts & Volumes, and Data Validation. Add widgets to the appropriate tab below. The complete JSON provides a reference for tab membership if you edit JSON directly.

> SCREENSHOT PLACEHOLDER — SS-06: Tab structure
> Capture the three tab names, with Overview selected.

### Step 5 — Configure the Overview request

In Overview, add a full-width Wildcard titled VCA DSI | Application portfolio · v14. Choose Timeseries. Configure exactly one request with three queries/formulas from Overview-Request.json. The appendix supplies complete copyable queries.

| Query name | Metric | Group by | Formula | Alias |
|---|---|---|---|---|
| idle | system.cpu.idle | application, host | 100-idle | cpu_pct |
| usable | system.mem.pct_usable | application, host | 100*(1-usable) | ram_pct |
| disk | system.disk.in_use | application, host, device | 100*disk | disk_pct |

If the editor assigns names a/b/c instead of idle/usable/disk, use its assigned names in formulas. Keep the aliases exactly as shown: they are the field names consumed by the visual. Copy the entire query text including scope, rollup and fill(null).

Do not add a Scalar request for summary values. The Overview calculates them from its time samples. The previous mixed Scalar/Timeseries configuration did not expose the expected timestamps in the user's account; the single-Timeseries component was confirmed working.

> SCREENSHOT PLACEHOLDER — SS-07: Overview request
> Capture one Timeseries request, three metric queries and all three aliases.

### Step 6 — Check Data Preview

Inspect table1. It must contain _time, host and the formula fields. application is requested for the portfolio, and device appears on disk series. Some fields can be null on individual rows because CPU/RAM and disk have different grouping dimensions.

_time is supplied by Datadog; it is not a metric or tag to add. If rows have no _time, check the request type and remove any extra requests. Never replace missing timestamps with the current time.

> SCREENSHOT PLACEHOLDER — SS-08: Temporal data
> Capture _time, host, application and populated CPU/RAM fields; include a device row if available.

### Step 7 — Apply the integrated visual

Open Define Visual, select Vega rather than Vega-Lite, and paste the complete Overview-Define-Visual-VEGA.json. Click Run.

Set the widget time preference to Global Time, not a local 1h period. In the delivered JSON no widget-level time object is present. Save the widget. Keep explicit text fill, text stroke and fixed background overrides absent so Datadog can supply its theme defaults.

> SCREENSHOT PLACEHOLDER — SS-09: Visual and Global Time
> Capture the eight-card preview and the Global Time preference.

### Step 8 — Check the time selector

Select Past 4 Hours at the top-right of the dashboard. All eight cards now receive data for that selection, subject to metric availability. The graph domain uses the returned timestamps; missing data at the start/end of a range cannot be invented.

The old local 1h setting and fixed 60-second rollup interval are removed. Datadog chooses the point interval while the requested aggregation method remains. Wider periods may therefore show coarser samples. This is not a hidden one-hour limit.

> SCREENSHOT PLACEHOLDER — SS-10: Four-hour view
> Capture Past 4 Hours and the application curves in the same frame.

### Step 9 — Create the host resources table

In Hosts & Volumes, create a group titled Hosts & volumes | compare all applications. Add a full-width Wildcard inside it. Select Scalar, configure the one request from Hosts-Request.json and paste Hosts-Define-Visual-VEGA.json in Vega mode. Use Global Time.

The columns are Application, Application ID, Environment, Host, CPU peak %, RAM peak %, Disk peak %, Min free GiB and Uptime h. Application is supplied by a local JSON catalogue, not a metric tag.

This is a custom table, not a native Query Table. It provides Previous/Next paging with 12 rows per page and alphabetical application/environment/host/volume ordering. Native Query Table search, sorting and drill-down menus are not reproduced. The request currently returns up to 100 rows; paging operates within that result limit.

> SCREENSHOT PLACEHOLDER — SS-11: Host table
> Capture readable names in the first column, metrics and pagination controls.

### Step 10 — Create the volume table

Below the host table, add another full-width Wildcard. Select Scalar, configure Volumes-Request.json and paste Volumes-Define-Visual-VEGA.json. Use Global Time.

Columns are Application, Application ID, Environment, Host, Volume, Disk peak %, Min free GiB and Total GiB. This table shows observed metric rows. It does not add expected missing volume rows like the C:/D: placeholders in an application cockpit.

Use about nine grid rows per table and enlarge the widget if labels or controls are clipped. Add a note below the group stating that labels come from the local catalogue and that missing hosts require an inventory check.

> SCREENSHOT PLACEHOLDER — SS-12: Volume table
> Capture the friendly names, hosts, actual volumes and capacities.

### Step 11 — Create Data Validation

In Data Validation, add a full-width Wildcard. Select Scalar, configure Data-Validation-Request.json and paste Data-Validation-Define-Visual-VEGA.json. Use Global Time.

Columns are Application, Application ID, Host, CPU peak %, RAM peak % and Disk peak %. This is a host-level source-summary table, not an availability check. Different spatial/time aggregation settings can produce small differences from the Overview; compare equivalent settings in Metrics Explorer.

> SCREENSHOT PLACEHOLDER — SS-13: Validation table
> Capture Application as the first column, followed by the technical ID and host.

### Step 12 — Maintain names without metric tags

Inside each table's specification.contents.data array, application_catalog contains eight friendly-name records and host_directory maps hosts to their expected application IDs/entities. The Overview calls its friendly-name dataset catalog.

```json
{"entity":"solutyo","application":"app07739","label":"Solutyo"}
```

To rename an application, edit label in the Overview catalog and in application_catalog in all three tables. Find these four occurrences in 00-Portfolio.json. Keep entity, host associations and metric application IDs unchanged for a name-only edit.

APPLICATION-CATALOG.json is reference material, not a file dynamically loaded by Datadog. Changing it alone does not update the dashboard. An invalid host/application mapping displays UNMAPPED APPLICATION rather than silently selecting the wrong name.

> SCREENSHOT PLACEHOLDER — SS-14: Name mapping
> Capture a catalogue label edit and the resulting first-column display, without modifying metric tags.

### Step 13 — Configure cockpit links

Import the application dashboards, copy their real Datadog URLs and populate cockpit_url for each Overview catalog entry. Empty URLs intentionally show Cockpit link not configured. Do not invent dashboard IDs. The links open the stored URL; they do not automatically forward the current time/environment selection.

> SCREENSHOT PLACEHOLDER — SS-15: Navigation
> Capture a working Open cockpit link and the matching application destination.

### Step 14 — Validate both appearance modes

Keep the same saved dashboard. Switch your Datadog user Appearance preference to Light, Dark, then System. System follows the operating-system preference. Do not import different dashboards for different modes.

Text and background defaults are left to Datadog. Resource colors remain semantic accents. Do not reintroduce white text, black text or *_contrast marks from an earlier release. Local preview images simulate a host theme; they are not evidence of the theme integration in your account.

> SCREENSHOT PLACEHOLDER — SS-16: Light appearance
> Capture the actual Datadog portfolio with readable dark text on a light background.

> SCREENSHOT PLACEHOLDER — SS-17: Dark appearance
> Capture the same dashboard with readable light text on a dark background.

### Step 15 — Save and export

Save and re-open the dashboard. Confirm Saved Views, links and team association persist. Export the accepted JSON and attach it to this Confluence page with its version/date. Keep the supplied source package separate from your customized export.

> SCREENSHOT PLACEHOLDER — SS-18: Accepted export
> Capture the saved title/version, team association and export action.

## Indicator reference

| Indicator | Calculation | Interpretation |
|---|---|---|
| CPU | 100 − system.cpu.idle | CPU time that is not idle |
| RAM | 100 × (1 − system.mem.pct_usable) | Memory fraction not immediately usable |
| Disk | 100 × system.disk.in_use | Occupied volume fraction |
| Pressure ring | Maximum CPU/RAM/disk peak | Resource pressure, not business availability |
| Fullest volume | Highest volume occupancy in the period | May belong to any host in that application |
| Minimum free GiB | Minimum system.disk.free / 1073741824 | Smallest observed free capacity in the selected range |
| Total GiB | Latest system.disk.total / 1073741824 | Last reported capacity in the selected range |
| Uptime h | Latest system.uptime / 3600 | OS uptime, not an application SLA |

Green means below 85%, amber 85% to below 95%, red 95% or higher. These are visual thresholds, not monitors. The package installs no alerts. N/A is unknown, not zero. A host can be missing even while another host keeps an application card green.

Portfolio peaks cover the selected period and can come from different hosts/timestamps. A longer period can reveal an older peak. Application cockpits use the latest CPU/RAM and last complete total/available pair in the selected range; a complete pair can be older than the latest CPU sample. A historical last value is not a live heartbeat.

Application cockpits retain C:/D: slots with NOT REPORTED for missing capacity and show other observed volumes. Used memory means total minus usable, not total minus strictly free. All widgets, including technical tabs and logs, now inherit Global Time.

## Acceptance checklist

| Check | Expected result | Evidence |
|---|---|---|
| Data architecture | One request per widget; Timeseries only in Overview | SS-07/08 |
| Time | Four-hour selector reaches all cards and tables | SS-09/10 |
| Light/Dark | Same dashboard, readable text in both modes | SS-16/17 |
| Environments | Production includes production/prd; Test stays separate | SS-05 |
| Names | Application is the first column of all three tables | SS-11/12/13 |
| Shared ID | Orion and licence-manager hosts have distinct labels | SS-11/14 |
| Teams | vca-dsi on all dashboards; vca-orion-ops additionally on Orion | SS-03 and Orion details |
| Paging | Previous/Next accesses all returned rows | SS-11 |
| Missing values | N/A/NOT REPORTED is distinct from zero | Add a missing-data capture |
| Export | Accepted customized JSON attached to this page | SS-18 |

## Troubleshooting

| Symptom | Action |
|---|---|
| Curves remain one hour | Remove local time overrides; use Global Time and v14 files |
| No _time | Ensure Overview has exactly one Timeseries request; inspect table1 |
| Disks absent but CPU works | Check device and disk metrics; do not group CPU by device |
| White text in Light mode | Remove explicit text fill/stroke and old *_contrast marks |
| UNMAPPED APPLICATION | Check host_directory and application_catalog together |
| Renaming has no effect | Edit each embedded catalogue, not just the reference file |
| Sage 100 absent in Production | Select Saved Views → Test |
| prd missing | Select the saved Production view with both values |
| Table cut off | Increase widget height and check pagination |
| Long range slow | Narrow time/environment; test large datasets and inventory growth |
| Empty logs | Check existing collection, tags, indexes and access; import does not enable collection |

## Logo in the title

The title of this custom dashboard is text; no arbitrary-image upload into that title is documented. A logo can appear inside an Image widget or a Group banner. Integration dashboards have a separate integration_id/icon mechanism for header logos; it is not a general custom-title logo setting. No logo or image widget was added.

## Validation boundary

The user confirmed the preceding single-Timeseries component works. v14 preserves that architecture. Local tests cover schema shape, global-time inheritance, text override removal, four-hour data across eight cards, friendly-name mapping, invalid data, paging and responsive layout. In-account import and theme acceptance remain necessary. Packaged preview images use simulated data and simulated host theme defaults.

## Official references

- [Wildcard themes and data mapping](https://docs.datadoghq.com/dashboards/guide/using_vega_lite_in_wildcard_widgets/)
- [Global and local widget time](https://docs.datadoghq.com/dashboards/widgets/configuration/)
- [Dashboard details, teams and tabs](https://docs.datadoghq.com/dashboards/configure/)
- [Dashboard ownership tags](https://docs.datadoghq.com/api/latest/dashboards/get-a-dashboard/)
- [Rollup behavior](https://docs.datadoghq.com/dashboards/functions/rollup/)
- [Image widget](https://docs.datadoghq.com/dashboards/widgets/image/)
- [Group banner](https://docs.datadoghq.com/dashboards/widgets/group/)
- [Integration header logos](https://docs.datadoghq.com/extend/integrations/create-an-integration-dashboard/)

## Appendix — Exact request recipes

The following recipes are generated from the delivered JSON. Copy each full query into the UI. Query names may be changed by the editor; if so, adjust formula references while retaining the required aliases. Use Global Time for every widget. The provided visual files are required attachments for this procedure.

### Overview — timeseries

Files: Overview-Request.json and Overview-Define-Visual-VEGA.json in 02-Widgets/00-Portfolio.

Query name: `idle`

```text
avg:system.cpu.idle{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,host}.rollup(min).fill(null)
```

Query name: `usable`

```text
avg:system.mem.pct_usable{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,host}.rollup(min).fill(null)
```

Query name: `disk`

```text
max:system.disk.in_use{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,host,device}.rollup(max).fill(null)
```

| Formula | Required alias |
|---|---|
| `100-idle` | `cpu_pct` |
| `100*(1-usable)` | `ram_pct` |
| `100*disk` | `disk_pct` |


### Hosts — scalar

Files: Hosts-Request.json and Hosts-Define-Visual-VEGA.json in 02-Widgets/00-Portfolio.

Query name: `q0` · Scalar time aggregator: `min`

```text
min:system.cpu.idle{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,environment,host}.fill(null)
```

Query name: `q1` · Scalar time aggregator: `min`

```text
min:system.mem.pct_usable{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,environment,host}.fill(null)
```

Query name: `q2` · Scalar time aggregator: `max`

```text
max:system.disk.in_use{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,environment,host}.fill(null)
```

Query name: `q3` · Scalar time aggregator: `min`

```text
min:system.disk.free{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,environment,host}.fill(null)
```

Query name: `q4` · Scalar time aggregator: `last`

```text
min:system.uptime{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,environment,host}.fill(null)
```

| Formula | Required alias |
|---|---|
| `100 - q0` | `cpu_pct` |
| `100 * (1 - q1)` | `ram_pct` |
| `100 * q2` | `disk_pct` |
| `q3 / 1073741824` | `disk_free_gib` |
| `q4 / 3600` | `uptime_h` |

Result limit: 100 rows. Pagination operates within the returned results.


### Volumes — scalar

Files: Volumes-Request.json and Volumes-Define-Visual-VEGA.json in 02-Widgets/00-Portfolio.

Query name: `q0` · Scalar time aggregator: `max`

```text
max:system.disk.in_use{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,environment,host,device}.fill(null)
```

Query name: `q1` · Scalar time aggregator: `min`

```text
min:system.disk.free{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,environment,host,device}.fill(null)
```

Query name: `q2` · Scalar time aggregator: `last`

```text
max:system.disk.total{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,environment,host,device}.fill(null)
```

| Formula | Required alias |
|---|---|
| `100 * q0` | `disk_pct` |
| `q1 / 1073741824` | `disk_free_gib` |
| `q2 / 1073741824` | `disk_total_gib` |

Result limit: 100 rows. Pagination operates within the returned results.


### Data-Validation — scalar

Files: Data-Validation-Request.json and Data-Validation-Define-Visual-VEGA.json in 02-Widgets/00-Portfolio.

Query name: `cpu_idle` · Scalar time aggregator: `min`

```text
min:system.cpu.idle{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,host}.fill(null)
```

Query name: `ram_available` · Scalar time aggregator: `min`

```text
min:system.mem.pct_usable{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,host}.fill(null)
```

Query name: `disk_used` · Scalar time aggregator: `max`

```text
max:system.disk.in_use{maison:vca AND ((application:app07656 AND host IN (sapp01055)) OR (application:app07739 AND host IN (sapp01051,sapp01077)) OR (application:app08213 AND host IN (sapp01078,sapp01098)) OR (application:app05236 AND host IN (sapp00185,sapp00184,sapp01044,sapp01045,sapp00178,sapp00177,sapp00175,sapp00176)) OR (application:app05236 AND host IN (sapp01129)) OR (application:app05236 AND host IN (slic00025)) OR (application:app05236 AND host IN (slic00027)) OR (application:app06976 AND host IN (sapp00951,sora00003))) AND environment IN (test,quality,pre-production,production,prd) AND $environment} by {application,host}.fill(null)
```

| Formula | Required alias |
|---|---|
| `100 - cpu_idle` | `cpu_pct` |
| `100 * (1 - ram_available)` | `ram_pct` |
| `100 * disk_used` | `disk_pct` |

Result limit: 100 rows. Pagination operates within the returned results.

