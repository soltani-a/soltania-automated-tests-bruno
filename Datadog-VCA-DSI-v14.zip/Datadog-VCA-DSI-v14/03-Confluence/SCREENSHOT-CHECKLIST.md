# Screenshot checklist

| ID | Screenshot | Expected content |
|---|---|---|
| SS-01 | Access and package | Capture the Dashboards landing page and extracted v14 package. Replace this block with the screenshot and caption. |
| SS-02 | Imported portfolio | Capture the title, three tabs, environment filter and global time selector. |
| SS-03 | Title and ownership | Capture the details panel with the correct title and selected vca-dsi team. |
| SS-04 | Environment variable | Capture its name, prefix and five available values. |
| SS-05 | Production aliases | Capture the Production Saved View and both production/prd in the filter. |
| SS-06 | Tab structure | Capture the three tab names, with Overview selected. |
| SS-07 | Overview request | Capture one Timeseries request, three metric queries and all three aliases. |
| SS-08 | Temporal data | Capture _time, host, application and populated CPU/RAM fields; include a device row if available. |
| SS-09 | Visual and Global Time | Capture the eight-card preview and the Global Time preference. |
| SS-10 | Four-hour view | Capture Past 4 Hours and the application curves in the same frame. |
| SS-11 | Host table | Capture readable names in the first column, metrics and pagination controls. |
| SS-12 | Volume table | Capture the friendly names, hosts, actual volumes and capacities. |
| SS-13 | Validation table | Capture Application as the first column, followed by the technical ID and host. |
| SS-14 | Name mapping | Capture a catalogue label edit and the resulting first-column display, without modifying metric tags. |
| SS-15 | Navigation | Capture a working Open cockpit link and the matching application destination. |
| SS-16 | Light appearance | Capture the actual Datadog portfolio with readable dark text on a light background. |
| SS-17 | Dark appearance | Capture the same dashboard with readable light text on a dark background. |
| SS-18 | Accepted export | Capture the saved title/version, team association and export action. |
