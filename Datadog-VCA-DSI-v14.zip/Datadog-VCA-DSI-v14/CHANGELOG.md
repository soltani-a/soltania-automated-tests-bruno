# Changes from v13 Fixed

- Removed explicit text colors/outlines and all local widget time windows.
- Preserved one Timeseries request per Overview; removed fixed rollup intervals.
- Added first-column application names and 12-row pagination to the three portfolio tables.
- Updated dashboard title prefixes and ownership tags.
- Added English Confluence instructions with 18 screenshot placeholders and exact request recipes.
- Excluded Treasure/Stone Cloud; no logo applied.
