# VCA DSI dashboards — v14

The working single-Timeseries Overview is retained. One dashboard uses Datadog appearance defaults. All widgets follow the global time selector. The portfolio's three tables show Application first, using editable embedded JSON catalogues.

Titles start with VCA DSI |. All dashboards have team:vca-dsi; Orion also has team:vca-orion-ops. Treasure/Stone Cloud is excluded as requested. No logo has been added.

## Install

1. Export the existing dashboard to preserve custom links and edits.
2. Create a new dashboard and import 01-Dashboards/00-Portfolio.json. Use Without-tabs only if tabs are rejected.
3. Select Production (production + prd), then Past 4 Hours. Check Light and Dark appearance using the same dashboard.
4. Check Application as the first column in Hosts, Volumes and Data Validation. Use Previous/Next for more rows.
5. Import 01-sage100.json through 08-proconcept.json. Customize 09-template.json before use. Confirm team association after import.
6. Add real cockpit URLs to the portfolio catalogue. Save and export the accepted version.

No script or server change is required. Widget/request/visual fragments are in 02-Widgets. The English Confluence tutorial in 03-Confluence provides 18 screenshot placeholders and exact request recipes. Copy rendered HTML content into your Confluence editor, check formatting, and upload/link the referenced JSON attachments. Markdown source is also supplied.

## Behavior and limits

Text colors/outlines previously imposed by the visual are removed. Actual Datadog theme acceptance still needs checking in your account. Local previews simulate host theme defaults; they are not account screenshots.

Time overrides are removed from every widget, including formerly fixed five-minute tables. Rollup methods remain but intervals are automatic. Longer selections summarize longer history and may return more data; large-window performance requires testing in the account.

Friendly names live in each visual's catalog or application_catalog. APPLICATION-CATALOG.json is a reference, not a dynamically loaded file. Host associations distinguish shared app05236 entries. The custom tables provide paging but do not reproduce native Query Table search/drill-down controls.

The custom dashboard title is text. A logo could be shown in an Image widget or Group banner; none is added. See the Confluence article for the integration-dashboard header exception and references.
