# Validation v14

20 dashboard JSON files: 10 with tabs, 10 without. 13 Wildcard visuals. SDK Datadog 2.61.0 validates concrete request branches separately from dashboard envelopes because of the Wildcard union ambiguity. No authenticated v14 import has been performed.

- All 10 visual specifications parse and render empty input
- Screenshot C example row: numeric _time, CPU 14.039377 and RAM 82 render; unreported C:/D: remain unknown
- Scalar-only row reproduces missing-time condition and is never given a fabricated timestamp
- Mixed host/device groups in one table: 120 temporal points, latest paired capacities 12/32 and 48/64 GiB, latest disk snapshot, absent D: unknown
- Sparse formula rows merge by host/time; numeric zero preserved; incomplete newer memory pair cannot invent used capacity; clearing data removes old values
- Number, numeric-string, Date and ISO timestamps supported
- Invalid capacities, booleans, blanks and unknown hosts do not become healthy readings
- Portfolio peaks, separate disk groups and shared app05236 scopes verified; wrong application/host pairing rejected
- Browser layout responds from four columns at 1600px to two at 800px
- All three table visuals: first column is application name; shared IDs resolve by host; unmapped pairs stay explicit
- Four-hour fixture: all eight application charts consume the full 4h time domain
- Global time inherited; no text color/stroke overrides; dashboard team tags added without filtering metric queries
- Actual browser click pagination: 18 hosts, first page 12 rows, next page 6, previous restores page one

Theme previews simulate host text defaults; they do not prove account integration. Four-hour fixtures verify four hours of input; removing local widget time makes the real request follow the global selector.
