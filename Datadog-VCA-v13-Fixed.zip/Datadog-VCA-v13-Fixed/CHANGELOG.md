# v13 Fixed — 3 octobre 2026

- Repart de la disposition v13, avec courbes intégrées dans les cartes.
- Remplace les trois demandes mixtes Scalar / Timeseries / Scalar par une seule demande Timeseries.
- Utilise table1 pour les horodatages, courbes, pics et dernières capacités complètes.
- Rend visibles les points isolés et les absences de séries temporelles.
- Ajoute les emplacements C:/D: ; les capacités manquantes restent NOT REPORTED.
- Impose des textes blancs avec contour sombre, y compris sur fond clair.
- Conserve les autres onglets, les filtres, les logs et les vues d'environnements.
- Fenêtre Overview 1h et rollup 60s explicites ; calculs décrits dans TUTORIAL.md.
