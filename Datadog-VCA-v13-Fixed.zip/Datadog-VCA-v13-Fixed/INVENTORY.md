# Inventaire v13 Fixed

| Application | ID | Environment | Hosts |
|---|---|---|---|
| Sage 100 | app07656 | test | sapp01055 |
| Solutyo | app07739 | quality | sapp01051 |
| Solutyo | app07739 | production | sapp01077 |
| Neofugu | app08213 | quality | sapp01078 |
| Neofugu | app08213 | production | sapp01098 |
| VCA Orion | app05236 | quality | sapp00185, sapp00184, sapp01044, sapp01045 |
| VCA Orion | app05236 | pre-production | sapp00178, sapp00177 |
| VCA Orion | app05236 | production | sapp00175, sapp00176 |
| Magics LM | app05236 | prd | sapp01129 |
| Solidworks LM | app05236 | prd | slic00025 |
| Hypermill LM | app05236 | prd | slic00027 |
| Proconcept | app06976 | production | sapp00951, sora00003 |
