# VCA — v13 Fixed

3 octobre 2026 · Design v13 avec courbes intégrées · Installation manuelle, sans script serveur

## Ce que la capture a établi

Dans le diagnostic Solutyo envoyé le 3 octobre : B/table2 affiche 1 ligne, 0 _time présent, 0 _time numérique, et cpu_pct/ram_pct null. C/table1, contenant la même requête Timeseries seule, affiche 362 lignes et 362 _time numériques, avec les valeurs CPU/RAM. La collecte est donc disponible et le chemin Timeseries seul fonctionne. Le composant mixte de la v13 ne reçoit pas le flux temporel attendu.

Cette observation ne prouve pas que Datadog interdit universellement le mélange Scalar/Timeseries. Elle suffit à identifier le chemin défaillant dans le widget testé. Ce pack le supprime : chaque Overview utilise désormais **une seule entrée requests**, de type **timeseries**, et **table1 est sa seule source externe**. Aucune date n'est inventée et aucun timestamp n'est ajouté aux métriques serveur.

Le dessin reprend la grille, les courbes intégrées, les anneaux et les barres de la v13. Les autres onglets et la liste native de logs sont conservés. Ce n'est pas le dashboard de diagnostic ni le remplacement par des graphiques natifs de la v13.1.

## Installer d'abord Solutyo

1. Décompressez entièrement l'archive. Conservez la v13 actuelle et son export JSON pour revenir en arrière et récupérer vos liens ou autres personnalisations.
2. Dans Datadog, créez un nouveau dashboard puis utilisez Import dashboard JSON / Import from JSON. Importez **01-Dashboards/02-solutyo.json** de ce dossier v13 Fixed.
3. Choisissez Saved Views → Production. Cette vue sélectionne production et prd. Le scope Solutyo conserve app07739 et les hosts sapp01051/sapp01077.
4. Ouvrez l'Overview. Les courbes CPU/RAM doivent être dans le panneau de sapp01077, au-dessus des capacités RAM et C:/D:.
5. Dans Edit → Data Preview du Wildcard, il n'y a plus trois requêtes à sélectionner. La requête Timeseries unique fournit _time et les aliases décrits plus bas. Les colonnes peuvent être nulles sur certaines lignes : par exemple les séries disque ont device, tandis que la CPU est groupée par host.
6. Comparez les courbes avec Metrics Explorer sur une heure et un rollup de 60 secondes. La capacité montre le dernier couple total/disponible complet disponible dans cette heure ; ce n'est pas une mesure instantanée garantie.
7. Si Solutyo est accepté, importez 00-Portfolio.json puis les autres applications du même dossier. 09-template.json reste facultatif et à personnaliser.

Le dossier Without-tabs contient la même version sans onglets, seulement si votre interface refuse les onglets à l'import. N'importez pas les deux variantes. Le dossier 02-Widgets contient des composants réutilisables ; aucune installation de plugin n'est nécessaire puisque les dashboards incluent déjà leurs widgets.

Les fichiers diagnostiques A/B/C/D ne doivent pas remplacer ces fichiers de production.

## Pourquoi il faut remplacer aussi les requêtes

Ne copiez pas seulement Define Visual dans l'ancien widget en laissant les trois requêtes v13. Le nouveau dessin lit des données différentes : **une requête Timeseries unique → table1 → séries et résumés calculés dans Vega**.

Pour remplacer un widget seul : utilisez 02-Widgets/<application>/Widget.json si l'éditeur permet une définition JSON complète. Sinon, supprimez les anciennes demandes dans la copie du widget, créez une seule demande Timeseries selon Timeseries-Request.json, conservez toutes les formules et leurs aliases, puis collez Define-Visual-VEGA.json dans Define Visual, mode Vega. Fixez la fenêtre locale à 1h. Le dashboard complet reste la méthode recommandée.

Un seul objet requests peut contenir plusieurs queries et formulas : cela reste une seule demande Timeseries, pas plusieurs demandes Scalar/Timeseries mélangées.

## Données attendues dans table1

| Dashboard | Aliases de formules |
|---|---|
| Portfolio | cpu_pct, ram_pct, disk_pct |
| Application | cpu_pct, ram_pct, memory_total_gib, memory_usable_gib, disk_total_gib, disk_free_gib |

_time est l'horodatage fourni par Datadog. host identifie le serveur ; application est aussi demandé dans le portfolio ; device identifie un volume pour les séries disque. Les formules CPU/RAM restent groupées par host, sans exiger un tag device sur ces métriques. Les formules disque sont groupées par host et device. Le composant réunit les mesures par host/horodatage, puis par host/device/horodatage pour les capacités disque. Les formules ne portent jamais le même alias pour la RAM et le disque.

Les horodatages numériques sont ceux observés sur votre capture. Le dessin accepte également des dates et des chaînes convertibles. Les champs absents, chaînes vides et valeurs invalides ne deviennent pas zéro. Les valeurs zéro réelles restent valides. Un point unique est rendu par un petit marqueur.

## Calculs et lecture

| Indicateur | Source / calcul | Lecture |
|---|---|---|
| CPU utilization | 100 − system.cpu.idle | Pourcentage de CPU non idle |
| RAM utilization | 100 × (1 − system.mem.pct_usable) | Fraction non utilisable immédiatement |
| Disk utilization | 100 × system.disk.in_use | Occupation d'un volume |
| Memory capacity | system.mem.total et system.mem.usable | Orange = total − utilisable ; bleu = utilisable |
| Volume capacity | system.disk.total et system.disk.free | Orange = total − libre ; bleu = libre |
| Portfolio pressure | Maximum CPU/RAM/disque dans le périmètre | Pression sur les ressources, pas disponibilité métier |
| Fullest volume | Volume ayant atteint le maximum d'occupation | Le host est indiqué dans l'infobulle de la carte |
| Application logs | Logs déjà collectés et indexés dans le scope | Liste native commune aux hosts sélectionnés |

Les capacités sont en GiB, soit octets / 1 073 741 824. La mémoire utilisable n'est pas seulement la mémoire strictement libre. L'utilisation est la différence entre deux valeurs du même intervalle ; le dessin refuse de soustraire un total récent à une capacité libre provenant d'un autre intervalle.

Le composant conserve une fenêtre locale d'une heure. Les requêtes sont regroupées par intervalles de 60 secondes pour limiter le nombre de lignes. Dans les cockpits, les courbes et capacités sont des moyennes par minute ; les chiffres affichent la dernière minute disponible. Si le couple total/disponible le plus récent est incomplet, le dernier couple complet est utilisé. Il peut donc être plus ancien que la dernière valeur CPU. Aucun indicateur ne doit être interprété comme une preuve de fraîcheur ou de disponibilité.

Dans le portfolio, le rollup conserve les pics : minimum de CPU idle et RAM utilisable, maximum d'occupation disque par minute, puis maximum sur l'heure pour les chiffres des cartes. Les pics CPU/RAM/disque d'une même carte peuvent provenir de hosts ou d'instants différents. Les courbes portfolio représentent le maximum par application à chaque point.

Ces agrégations peuvent produire de petites différences avec un graphique natif configuré sur une autre période ou un autre rollup. Les onglets techniques conservés gardent leur paramétrage local initial, notamment cinq minutes pour certains widgets.

Références : [rollup Datadog](https://docs.datadoghq.com/dashboards/functions/rollup/) et [données Wildcard](https://docs.datadoghq.com/dashboards/guide/using_vega_lite_in_wildcard_widgets/).

## C: et D: sans inventer de disques

Chaque panneau d'un host observé prévoit C: et D:. Si la métrique d'un volume n'existe pas ou n'est pas exploitable, la ligne reste grisée avec NOT REPORTED. Ce libellé ne signifie ni zéro octet ni disque plein. Les autres volumes effectivement observés, par exemple E:, sont ajoutés. Les valeurs C:\ et D:\ sont normalisées en C: et D: pour l'affichage ; aucun volume physique inconnu n'est renommé arbitrairement.

Dans le portfolio, la carte continue d'afficher le volume le plus rempli pour conserver la densité v13. Le détail C:/D: est dans les cockpits.

## Contraste et préférences utilisateur

Il n'y a qu'un jeu de dashboards. Les fonds des cartes sont transparents et laissent voir le thème du dashboard. Les textes sont **explicitement blancs avec un fin contour sombre** : ils ne dépendent donc pas d'une éventuelle couleur noire par défaut de Vega en mode sombre.

Ce choix garantit la même construction visuelle sur fond clair ou sombre, mais **le texte reste blanc avec contour en mode clair** ; il ne bascule pas automatiquement en texte noir. Le pack ne prétend pas disposer d'un signal interne Datadog non documenté pour détecter le thème de l'utilisateur. Les autres widgets natifs suivent les préférences Appearance Dark/Light/System de Datadog.

Les quatre aperçus montrent le véritable code Vega avec des fonds et données simulés. Ils servent à vérifier la disposition et le contraste, pas à confirmer la connexion à votre Datadog.

## Environnements et applications

| Vue enregistrée | Valeurs environment |
|---|---|
| Production | production et prd |
| Quality | quality |
| Test | test |
| Pre-production | pre-production |
| All environments | Toutes les valeurs autorisées |

Utilisez Saved Views → Production pour les deux orthographes ; une sélection brute production seule ne sélectionne pas prd. Sage 100 est uniquement en Test. Les seuls tags requis restent maison:vca, application, environment et host. Les labels lisibles ne sont pas des tags supplémentaires.

| Application | ID | Environment | Hosts |
|---|---|---|---|
| Sage 100 | app07656 | test | sapp01055 |
| Solutyo | app07739 | quality | sapp01051 |
| Solutyo | app07739 | production | sapp01077 |
| Neofugu | app08213 | quality | sapp01078 |
| Neofugu | app08213 | production | sapp01098 |
| VCA Orion | app05236 | quality | sapp00185, sapp00184, sapp01044, sapp01045 |
| VCA Orion | app05236 | pre-production | sapp00178, sapp00177 |
| VCA Orion | app05236 | production | sapp00175, sapp00176 |
| Magics LM | app05236 | prd | sapp01129 |
| Solidworks LM | app05236 | prd | slic00025 |
| Hypermill LM | app05236 | prd | slic00027 |
| Proconcept | app06976 | production | sapp00951, sora00003 |

Orion, Magics LM, Solidworks LM et Hypermill LM partagent app05236. La séparation par host est conservée dans les scopes et dans le catalogue graphique. Un host inconnu est exclu ; un application ID explicitement incompatible avec son host est rejeté. Le template contient application_id_to_customize et host_to_customize et ne doit pas être utilisé tel quel.

## Limites de santé et diagnostic

Vert <85 %, orange 85–<95 %, rouge ≥95 % : seuils visuels, pas alertes installées. Un indicateur absent reste inconnu. Une ressource connue élevée peut être rouge même si le score complet est N/A. Des hosts muets peuvent ne pas être détectés lorsqu'un autre host fournit des valeurs ; le vert ne signifie donc pas que tous les serveurs et toutes les fonctions de l'application sont disponibles.

Les panneaux applicatifs ne montrent que les hosts ayant des échantillons horodatés dans le scope. La présence d'une ligne C:/D: ne crée pas une preuve de collecte. Une liste de logs vide n'est pas une preuve d'absence d'erreurs.

Si les courbes restent vides :

1. Vérifiez qu'il reste une seule demande Timeseries et que le bon fichier v13 Fixed a été importé.
2. Dans Data Preview, vérifiez _time, host, cpu_pct et ram_pct. Les autres aliases concernent les capacités et peuvent être nulls sur certaines lignes.
3. Un message NO USABLE TIME DATA indique que le composant reçoit des lignes mais aucune ligne horodatée correspondant au scope/cataloque. Ne remplacez pas _time par l'heure actuelle.
4. Si cpu_pct/ram_pct sont présents mais pas les capacités, inspectez séparément les métriques mémoire/disque et leur tag device dans Metrics Explorer. Le composant conserve les courbes même sans capacités.
5. Vérifiez les limites de cardinalité si vous étendez l'inventaire ou la période. Le rollup 60 secondes réduit le volume ; il ne garantit pas un nombre maximal de lignes pour un inventaire arbitraire. Datadog recommande d'éviter les visualisations dépassant 5 000 lignes par demande : [limites Wildcard](https://docs.datadoghq.com/dashboards/widgets/wildcard/).

Aucune configuration Agent, nouvelle collecte, intégration SQL/SonarQube ou monitor n'est appliqué par ce package.

## Affichage, liens et maintenance

Le portfolio reprend quatre colonnes sur écran large. Dans Define Visual → signals, maxColumns = 4 et minCardWidth = 290 pilotent la densité. Les widgets utilisent la largeur de leur conteneur. Pour voir davantage de cartes, augmentez maxColumns et utilisez le plein écran ; réduire minCardWidth peut tronquer les labels. La hauteur de la cellule Datadog reste réglable manuellement, notamment pour Orion Quality ou All environments.

Pour activer les liens, importez les cockpits puis reportez leurs URL réelles dans data.catalog → cockpit_url du portfolio. Les liens restent non configurés par défaut et ne transmettent pas automatiquement l'environnement. Les personnalisations faites dans votre compte ne sont pas connues du package ; reportez-les depuis votre export sauvegardé.

Pour une nouvelle application, remplacez partout les placeholders du template. Adaptez les listes de hosts dans toutes les requêtes, dans les logs et dans data.host_directory. Le portfolio demande aussi une entrée data.catalog et des scopes étendus. Les décomptes « 8 applications / 18 hosts » sont des textes statiques à mettre à jour. INVENTORY.json est documentaire : son édition seule ne change pas Datadog.

## Validation effectuée

Le problème observé sur votre capture est reproduit avec une ligne scalaire sans _time ; le composant ne lui invente pas d'historique. La ligne Timeseries de C (_time numérique, CPU 14.039377, RAM 82) est utilisée comme cas de test. Sont également testés : lignes de formules séparées ou réunies, calcul de la dernière capacité complète, C:/D: absents, autres volumes, données invalides, scopes partagés, suppression des données et redimensionnement.

Les schémas sont contrôlés localement avec le SDK Datadog. Les requêtes Timeseries et l'enveloppe Wildcard sont validées séparément à cause de l'union ambiguë du SDK. Ces contrôles ne sont pas une validation d'import par l'API Datadog. La requête Timeseries seule a été confirmée par votre diagnostic ; la nouvelle requête enrichie et les calculs de cette version restent à vérifier avec vos données après import.
