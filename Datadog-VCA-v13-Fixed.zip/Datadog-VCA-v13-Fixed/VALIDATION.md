# Validation v13 Fixed

20 dashboards JSON : dix principaux et dix sans onglets. Dix widgets avec exactement une requête Timeseries et une seule source externe table1. Définitions hors Overview comparées à la v13 et conservées.

SDK Datadog 2.61.0 : branche Timeseries explicite puis enveloppe Dashboard/Wildcard séparée. Pas de test authentifié de la nouvelle requête enrichie.

Vega 5.30.0 :

- All 10 visual specifications parse and render empty input
- Screenshot C example row: numeric _time, CPU 14.039377 and RAM 82 render; unreported C:/D: remain unknown
- Scalar-only row reproduces missing-time condition and is never given a fabricated timestamp
- Mixed host/device groups in one table: 120 temporal points, latest paired capacities 12/32 and 48/64 GiB, latest disk snapshot, absent D: unknown
- Sparse formula rows merge by host/time; numeric zero preserved; incomplete newer memory pair cannot invent used capacity; clearing data removes old values
- Number, numeric-string, Date and ISO timestamps supported
- Invalid capacities, booleans, blanks and unknown hosts do not become healthy readings
- Portfolio peaks, separate disk groups and shared app05236 scopes verified; wrong application/host pairing rejected
- Browser layout responds from four columns at 1600px to two at 800px

Les aperçus sont simulés. Les données de capacité et les courbes complètes des aperçus ne proviennent pas de votre compte.
